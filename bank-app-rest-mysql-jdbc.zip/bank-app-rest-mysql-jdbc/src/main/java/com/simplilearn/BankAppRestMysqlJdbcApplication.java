package com.simplilearn;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BankAppRestMysqlJdbcApplication {

	public static void main(String[] args) {
		SpringApplication.run(BankAppRestMysqlJdbcApplication.class, args);
	}

}
