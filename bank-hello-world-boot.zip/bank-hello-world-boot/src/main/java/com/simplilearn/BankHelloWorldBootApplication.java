package com.simplilearn;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BankHelloWorldBootApplication {

	public static void main(String[] args) {
		SpringApplication.run(BankHelloWorldBootApplication.class, args);
	}

}
