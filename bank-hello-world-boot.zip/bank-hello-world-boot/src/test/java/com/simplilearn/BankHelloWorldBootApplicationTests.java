package com.simplilearn;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BankHelloWorldBootApplicationTests {

	@Test
	void contextLoads() {
	}

}
