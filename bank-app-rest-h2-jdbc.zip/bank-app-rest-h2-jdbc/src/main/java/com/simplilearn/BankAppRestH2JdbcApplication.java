package com.simplilearn;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BankAppRestH2JdbcApplication {

	public static void main(String[] args) {
		SpringApplication.run(BankAppRestH2JdbcApplication.class, args);
	}

}
